<?php 
	defined('BASEPATH') OR exit('direct script access not allowed');
	
	class Adverties extends CI_Controller
	{		
		function __construct()
		{
			parent::__construct();
			if(isset($this->session->userdata['mainAdmin'])){
				$data['user'] = $this->session->userdata('mainAdmin');
			}else{
				redirect('/');				
			}
		}

		public function adverties_details()
		{
			if(isset($this->session->userdata['mainAdmin'])){
				$data['user'] = $this->session->userdata('mainAdmin');
			}
			$data['flash']['active'] = $this->session->flashdata('active');
	    	$data['flash']['title'] = $this->session->flashdata('title');
	    	$data['flash']['text'] = $this->session->flashdata('text');
	    	$data['flash']['type'] = $this->session->flashdata('type');
			$data['page'] = 'Adverties';
			$data['adv_details'] = $this->Home_model->fetch_details('adv_isDelete=0','ad_adverties');
			// $data['member_details'] = $this->Home_model->fetch_details('member_soc_id='.$data['user']['soc_id'].' AND member_role_id != 2 AND member_name !="" AND member_is_deactive=0','rs_member');
			$this->load->view('Home/header',$data);
			$this->load->view('Adverties/adv_details',$data);
			$this->load->view('Adverties/adv_footer',$data);
		}

		public function register_adverties()
		{
			if(isset($this->session->userdata['mainAdmin'])){
				$data['user'] = $this->session->userdata('mainAdmin');
			}
			$data['page'] = 'Adverties';

			$data['all_pub']=$this->Home_model->fetch_details('pub_isDelete=0','ad_publication');
			$this->load->view('Home/header',$data);
			$this->load->view('Adverties/new_adv',$data);
			$this->load->view('Adverties/adv_footer',$data);
		}
		public function getDetails() //for javascript
		{
			$pub = $_POST['pub'];
			$data= $this->db->from('ad_publication')->join('ad_periodicity','pub_periodicity_id = per_id')->where('pub_id='.$pub.' AND pub_isDelete=0')->get()->result_array(); //select('per_name')->
			
			//$data= $this->Home_model->fetch_details('rate_pub_id='.$pub.' AND rate_isDelete=0','ad_rate');

			echo json_encode($data);
		}
		public function getRateSizeDetails()
		{
			$pub = $_POST['pub'];
			$data= $this->db->from('ad_rate')->join('ad_publication','rate_pub_id = pub_id')->join('ad_size','rate_size_id=size_id')->where('rate_pub_id='.$pub.' AND rate_isDelete=0 AND size_isDelete=0 ' )->get()->result_array();
			echo json_encode($data);
		}

		public function getSizeDetailsAdv()
		{
			$pub = $_POST['pub'];
			$size = $_POST['size'];
			$data=$this->Home_model->fetch_details('rate_isDelete=0 AND rate_pub_id='.$pub.' AND rate_size_id='.$size.'','ad_rate');
			echo json_encode($data);
		}

		public function insert_Adv()
		{
			
			$adv['adv_for'] = $this->input->post('adv_for');
			$adv['adv_pub_id'] = $this->input->post('adv_pub_id');
			$adv['adv_periodicity'] = $this->input->post('adv_periodicity');
			$adv['adv_size_id'] = $this->input->post('adv_size_id');
			$adv['adv_size_height'] = $this->input->post('adv_size_height');
			$adv['adv_size_width'] = $this->input->post('adv_size_width');

			$this->Home_model->insert_records('ad_adverties',$adv);
			$this->session->set_flashdata('active',1);
		    $this->session->set_flashdata('title',"Thank You.");
		    $this->session->set_flashdata('text',"Adverties has been Submitted."); 
		    $this->session->set_flashdata('type',"sucess");
			redirect('adverties');

		}

	}
?>