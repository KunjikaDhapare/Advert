<?php 
	defined('BASEPATH') OR exit('direct script access not allowed');
	
	class Publication extends CI_Controller
	{		
		function __construct()
		{
			parent::__construct();
			if(isset($this->session->userdata['mainAdmin'])){
				$data['user'] = $this->session->userdata('mainAdmin');
			}else{
				redirect('/');				
			}
		}

		public function publication_details()
		{
			if(isset($this->session->userdata['mainAdmin'])){
				$data['user'] = $this->session->userdata('mainAdmin');
			}elseif(isset($this->session->userdata['flatOwner'])){
				$data['user'] = $this->session->userdata('flatOwner');
			}
			$data['flash']['active'] = $this->session->flashdata('active');
	    	$data['flash']['title'] = $this->session->flashdata('title');
	    	$data['flash']['text'] = $this->session->flashdata('text');
	    	$data['flash']['type'] = $this->session->flashdata('type');
			$data['page'] = 'publication';


			$data['publication_details'] = $this->Home_model->fetch_details('pub_isDelete=0','ad_publication');

			$data['periodicity'] = $this->Home_model->fetch_details('per_isDelete=0','ad_periodicity');

			$data['contact'] = $this->Home_model->fetch_details('cont_isDeleted=0 AND cont_for=3 AND cont_role=2','ad_contact');

			$data['pub_size_type']=$this->Home_model->fetch_details('size_type_isDelete= 0','ad_size_type');


			 //pub_com_id='.$data['user']['soc_id'].'AND

			
			// $data['member_details'] = $this->Home_model->fetch_details('member_soc_id='.$data['user']['soc_id'].' AND member_role_id != 2 AND member_name !="" AND member_is_deactive=0','rs_member');
			$this->load->view('Home/header',$data);
			$this->load->view('Publication/publication_details',$data);
			$this->load->view('Publication/publication_footer',$data);
		}

		public function register_publication()
		{
			if(isset($this->session->userdata['mainAdmin'])){
				$data['user'] = $this->session->userdata('mainAdmin');
			}elseif(isset($this->session->userdata['flatOwner'])){
				$data['user'] = $this->session->userdata('flatOwner');
			}
			$data['page'] = 'publication';
			$user_id= $data['user']['id'];

			$data['all_com']=$this->Home_model->fetch_details('com_isDelete=0 AND com_createdby='.$user_id.' ','ad_company');
			$data['periodicity']=$this->Home_model->fetch_details('per_isDelete=0 AND per_com_id='.$user_id.' ','ad_periodicity');
			$data['size_type']=$this->Home_model->fetch_details('size_type_isDelete=0 AND size_type_com_id='.$user_id.' ','ad_size_type');

			//print_r($data['all_com']);

			$data['periodicity']=$this->Home_model->fetch_details('per_isDelete= 0','ad_periodicity');
			
			$this->load->view('Home/header',$data);
			$this->load->view('Publication/new_publication',$data);
			$this->load->view('Publication/publication_footer',$data);
		}

		public function new_publication() // insert into db
		{
			if(isset($this->session->userdata['mainAdmin'])){
				$data['user'] = $this->session->userdata('mainAdmin');
			}elseif(isset($this->session->userdata['flatOwner'])){
				$data['user'] = $this->session->userdata('flatOwner');
			}
			
			$pub['pub_name'] = $this->input->post('pub_name');
			$pub['pub_reg_no'] = $this->input->post('pub_reg');
			$pub['pub_com_id'] = $this->input->post('pub_company');

			$pub['pub_contact'] = $this->input->post('pub_contact');
			$pub['pub_email'] = $this->input->post('pub_email');
			$pub['pub_website'] = $this->input->post('pub_website');
			
			$pub['pub_country'] = 101;
			$pub['pub_state'] = $this->input->post('pub_state');
			$pub['pub_city'] = $this->input->post('pub_city');
			$pub['pub_pincode'] = $this->input->post('pub_pincode');


			$pub['pub_size_type'] = $this->input->post('pub_size_type');
			$pub['pub_actual_height'] = $this->input->post('pub_actual_height');
			$pub['pub_actual_width'] = $this->input->post('pub_actual_width');
			$pub['pub_print_height'] = $this->input->post('pub_print_height');
			$pub['pub_print_width'] = $this->input->post('pub_print_width');
			$pub['pub_periodicity_id'] = $this->input->post('pub_periodicity_id');

			$pub['pub_address'] = $this->input->post('pub_address');
			$pub['pub_createdby'] = $data['user']['id'];
			$pub['pub_publish_date'] = $this->input->post('pub_publish_date');
			$pub['pub_publish_date_1'] = $this->input->post('pub_publish_date_1');
			$pub['pub_publish_date_2'] = $this->input->post('pub_publish_date_2');
			$pub['pub_publish_date_3'] = $this->input->post('pub_publish_date_3');
			$pub['pub_publish_date_4'] = $this->input->post('pub_publish_date_4');

			$this->Home_model->insert_records('ad_publication',$pub);
			$id= $this->db->insert_id();

			$contact1['cont_name']=$this->input->post('member_name1');
			$contact1['cont_mobile']=$this->input->post('member_mobile1');
			$contact1['cont_email']=$this->input->post('member_email1');
			$contact1['cont_for']=3;
			$contact1['cont_role']=1;	//publisher		
			$contact1['cont_for_id']=$id;

			$this->Home_model->insert_records('ad_contact',$contact1);

			if($this->input->post('member_name2'))
			{
				$contact2['cont_name']=$this->input->post('member_name2');
				$contact2['cont_mobile']=$this->input->post('member_mobile2');
				$contact2['cont_email']=$this->input->post('member_email2');
				$contact2['cont_for']=3;
				$contact2['cont_role']=2; //incharge
				$contact2['cont_for_id']=$id;
				$this->Home_model->insert_records('ad_contact',$contact2);
			}

			redirect('publication');
			//print_r($this->input->post('per_name'));

		}

	}
?>