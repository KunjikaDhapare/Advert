<?php 
	defined('BASEPATH') OR exit('direct script access not allowed');
	
	class Company extends CI_Controller
	{		
		function __construct()
		{
			parent::__construct();
			if(isset($this->session->userdata['mainAdmin'])){
				$data['user'] = $this->session->userdata('mainAdmin');
			}else{
				redirect('/');				
			}
		}

		public function company_details()
		{
			if(isset($this->session->userdata['mainAdmin'])){
				$data['user'] = $this->session->userdata('mainAdmin');
			}elseif(isset($this->session->userdata['flatOwner'])){
				$data['user'] = $this->session->userdata('flatOwner');
			}
			$data['flash']['active'] = $this->session->flashdata('active');
	    	$data['flash']['title'] = $this->session->flashdata('title');
	    	$data['flash']['text'] = $this->session->flashdata('text');
	    	$data['flash']['type'] = $this->session->flashdata('type');
			$data['page'] = 'publication';
			$id=$data['user']['id'];
			$data['company_details'] = $this->Home_model->fetch_details('com_createdby='.$id.' AND  com_isDelete=0','ad_company');
			// $data['member_details'] = $this->Home_model->fetch_details('member_soc_id='.$data['user']['soc_id'].' AND member_role_id != 2 AND member_name !="" AND member_is_deactive=0','rs_member');
			$this->load->view('Home/header',$data);
			$this->load->view('Company/company_details',$data);
			$this->load->view('Company/company_footer',$data);
		}

		public function register_company()
		{
			if(isset($this->session->userdata['mainAdmin'])){
				$data['user'] = $this->session->userdata('mainAdmin');
			}elseif(isset($this->session->userdata['flatOwner'])){
				$data['user'] = $this->session->userdata('flatOwner');
			}
			$data['page'] = 'publication';
			$this->load->view('Home/header',$data);
			$this->load->view('Company/new_company',$data);
			$this->load->view('Company/company_footer',$data);
		}

			public function new_company() // insert into db
		{
			if(isset($this->session->userdata['mainAdmin'])){
				$data['user'] = $this->session->userdata('mainAdmin');
			}elseif(isset($this->session->userdata['flatOwner'])){
				$data['user'] = $this->session->userdata('flatOwner');
			}
			
			$company['com_name'] = $this->input->post('company_name');
			$company['com_contact'] = $this->input->post('company_contact');
			$company['com_email'] = $this->input->post('company_email');
			$company['com_createdby'] = $data['user']['id'];

			//print_r($company);
			$this->Home_model->insert_records('ad_company',$company);
			$id= $this->db->insert_id();

			//print_r($id);

			$contact['cont_name']=$this->input->post('cp_name');
			$contact['cont_mobile']=$this->input->post('cp_mobile');
			$contact['cont_email']=$this->input->post('cp_email');
			$contact['cont_for']=2;
			$contact['cont_for_id']=$id;

			print_r($contact);
			
			$this->Home_model->insert_records('ad_contact',$contact);

			//redirect('company');
			//print_r($this->input->post('per_name'));

		}

	}
?>