<?php 
	defined('BASEPATH') OR exit ('No direct script access allowed.');

	class Home extends CI_Controller
	{
		public function index()
		{
			$data['error'] = $this->session->flashdata('error');
			$data['success'] = $this->session->flashdata('success');
			$data['Disabled'] = $this->session->flashdata('Disabled');
			$this->load->view('Home/login',$data);
		}

		public function register_society_data()
		{
			$data['flash']['active'] = $this->session->flashdata('active');
	    	$data['flash']['title'] = $this->session->flashdata('title');
	    	$data['flash']['text'] = $this->session->flashdata('text');
	    	$data['flash']['type'] = $this->session->flashdata('type');
			$where = 'ct_id IN (2763,5742)';
			// $data['user'] = $this->session->userdata('mainAdmin');
			$data['state'] = '22';
			$data['state_details'] = $this->Home_model->fetch_details('','rs_state');
			$data['society_type_details'] = $this->Home_model->fetch_details('','rs_society_categories_types');
			$data['city_details'] = $this->Home_model->fetch_details($where,'rs_cities');
			$data['page'] = 'society';
			// $this->load->view('Home/header',$data);
			$this->load->view('Society/new_society',$data);
		}

		public function register_society_records_data()
		{
			$data = $this->input->post();
			// Society Details
			$soc['soc_name'] = $this->input->post('soc_name');
			$soc['soc_SRN'] = $this->input->post('soc_SRN');
			$soc['soc_SFY'] = $this->input->post('soc_SFY');
			$soc['soc_no_of_flat'] = $this->input->post('soc_no_of_flat');
			$soc['soc_no_shop'] = $this->input->post('soc_no_shop');
			$soc['soc_category'] = $this->input->post('soc_category');
			$soc['soc_Phone'] = $this->input->post('soc_Phone');
			$soc['soc_email'] = $this->input->post('soc_email');
			$soc['soc_website'] = $this->input->post('soc_website');
			$soc['soc_country'] = 'India';
			$soc['soc_state'] = $this->input->post('soc_state');
			$soc['soc_city'] = $this->input->post('soc_city');
			$soc['soc_area'] = $this->input->post('soc_area');
			$soc['soc_pincode'] = $this->input->post('soc_pincode');
			$soc['soc_address'] = $this->input->post('soc_address');
			$soc['soc_logo'] = $this->Home_model->upload_profile('soc_logo','images');
			$soc['soc_createdby'] = 1;
			$soc['soc_createdon'] = date('Y-m-d');
			$soc['soc_sub_period'] =  $this->input->post('soc_sub_period');
			$soc['soc_sub_start'] =  date('Y-m-d');
			$soc['soc_payment_status'] =  1;
			if($this->input->post('soc_sub_period') == 3){
				$soc['soc_sub_end'] =  date('Y-m-d', strtotime('+3 months'));
			}else{
				$soc['soc_sub_end'] =  '';
			}
			$soc['soc_payment_mode'] =  $this->input->post('soc_payment_mode');
			// Society Admin
			$member['member_name'] = $this->input->post('member_name');
			$member['member_mobile'] = $this->input->post('member_mobile');
			$member['member_email'] = $this->input->post('member_email');
			$member['member_role_id'] = 2;
			$member['member_createdby'] = 1;
			$password = $this->rand_gen->generate(10);
			$member['member_salt'] = $this->Home_model->salt(32);
			$member['member_password'] = $this->Home_model->make($password.$member['member_salt']);
			$member['member_owner_type'] = 0;
			// Payment Details
			$payment['beta_payment'] = $this->input->post('beta_payment');
			$payment['payment_amount'] = $this->input->post('soc_amount_paid');
			$subject = 'Welcome in colonia.';
			$msg = "<div style='width:95%;padding:2%;'><div style='border:4px solid red;padding:2%;'><div class='row' style='color:red;text-align:right;font-weight:bold;font-size: 24px;    padding-right: 2%;'>COLONIA</div><div style='font-size: small;text-decoration: underline;text-align: right;color: red;font-weight: bold;'>Connect || Collaborate || Cluster</div><div style='padding:2%;'>Dear ".$member['member_name'].",<br><br>Welcome to Colonia, the pioneer platform for managing your society smartly! <br><br>Colonia offers you all the tools to ease your tasks of managing the society. We have developed it specially to fulfill the needs so that your society management operations can start quickly. Out technical team is always there to support so in any difficulty do get in touch with sales@colonia.in! We are just an email away.<br><br>To get started Just  click @  [<a href='http://www.colonia.in/RegisterSociety/' target='_blank'> http://www.colonia.in/RegisterSociety/</a>] <br><br>Login User Name: ".$member['member_email']."<br>Password: ".$password."<br>And start accessing various features!.<br><br><div class='row' style='color:red;font-weight:bold;padding: 0px 0px;'><br>Regards,<br> Team Colonia.</div><div style='text-align:center;''><img src='https://colonia.in/RegisterSociety/assets/images/think-before-you-print.jpg' style='width:60%;'></div><div style='text-align:center;'>This is an auto generated e-mail. Please do not reply.</div></div>";
			$email_status = $this->Home_model->send_mail($member['member_email'],$subject,$msg); 
			if($email_status == 1){
				$this->Home_model->insert_records('rs_society',$soc);
				$member['member_soc_id'] = $this->db->insert_id();
				$payment['society_id'] = $this->db->insert_id();
				$this->Home_model->insert_records('rs_member',$member);
				$this->Home_model->insert_records('rs_offline_payment',$payment);
					$this->session->set_flashdata('active',12);
		        $this->session->set_flashdata('title',"Thank You.");
		        $this->session->set_flashdata('text',"Thank you for registering society with Colonia (India) an email has been sent on registered society admin email."); 
		        $this->session->set_flashdata('type',"success");
				redirect('registerSociety');
			}else{
				$this->session->set_flashdata('active',1);
		        $this->session->set_flashdata('title',"Sorry.");
		        $this->session->set_flashdata('text',"Please enter valid admin emailId."); 
		        $this->session->set_flashdata('type',"warning");
				redirect('registerSociety');	
			}
		}

		public function area_details()
		{
			$city = $_POST['city'];
			$where = array('foren_no'=> $city);
			$data = $this->Home_model->fetch_details($where,'rs_ward');
			echo json_encode($data);
		}

		public function dashboard()
		{
			if(isset($this->session->userdata['mainAdmin'])){
				$data['user'] = $this->session->userdata('mainAdmin');
			}elseif(isset($this->session->userdata['socAdmin'])){
				$data['user'] = $this->session->userdata('socAdmin');
			}else{
				redirect('/');				
			}
			$data['error'] = $this->session->flashdata('error');
			$data['success'] = $this->session->flashdata('success');
			$data['Disabled'] = $this->session->flashdata('Disabled');
			$data['page'] = 'dashboard';
			$this->load->view('Home/header',$data);
			$this->load->view('Home/homepage');
			$this->load->view('Home/footer',$data);
		}

		public function login_check()
		{
			$this->form_validation->set_rules('user_email','trim|required');
			$this->form_validation->set_rules('user_password','password','trim|required');

			if($this->form_validation->run() == FALSE){
				$this->session->set_flashdata('error','Please enter the details.');
				redirect('/');

			}else{
				$data['username'] = $this->input->post('user_email');
				$data['password'] =  $this->input->post('user_password');
				$log_check = $this->Home_model->login_check($data);
				if($log_check == 1){
					$this->session->set_flashdata('error','Username is not register with us.');
				}elseif($log_check == 2){
					// $this->session->set_userdata('username',$data['username']);
					$this->session->set_flashdata('error','Please enter correct password.');
				}elseif($log_check == 3){
					// $this->session->set_userdata('username',$data['username']);
					$this->session->set_flashdata('error','Society Not Approved.. Please contact for admin.');
				}
				redirect('/');
			}
		}

		public function log_out()
		{
			if(isset($this->session->userdata['mainAdmin'])){
				$data['user'] = $this->session->userdata('mainAdmin');
			}elseif(isset($this->session->userdata['socAdmin'])){
				$data['user'] = $this->session->userdata('socAdmin');
			}elseif(isset($this->session->userdata['flatOwner'])){
				$data['user'] = $this->session->userdata('flatOwner');
			}elseif(isset($this->session->userdata['socChairman'])){
				$data['user'] = $this->session->userdata('socChairman');
			}elseif(isset($this->session->userdata['socChairman'])){
				$data['user'] = $this->session->userdata('socChairman');
			}
			$this->Home_model->logout_user($data);			
		}

		public function forgot_password()
		{
			$data['error'] = $this->session->flashdata('error');
			$data['success'] = $this->session->flashdata('success');
			$data['Disabled'] = $this->session->flashdata('Disabled');
			$this->load->view('Home/forgot_password',$data);
		}

		public function update_password()
		{
			$this->form_validation->set_rules('user_email','trim|required');
			$this->form_validation->set_rules('user_password','password','trim|required');

			if($this->form_validation->run() == FALSE){
				$this->session->set_flashdata('error','Please enter the details.');
				redirect('forgotPasaword');
			}else{
				$data['username'] = $this->input->post('user_email');
				$data['password'] =  $this->input->post('user_password');
				$log_check = $this->Home_model->update_password($data);
				if($log_check == 1){
					$this->session->set_flashdata('error','Username is not register with us.');
				}elseif($log_check == 2){
					$this->session->set_flashdata('error','Please enter correct password.');
				}
				redirect('forgotPasaword');
			}
		}

		public function update_profile()
		{
			if(isset($this->session->userdata['socAdmin'])){
				$data['user'] = $this->session->userdata('socAdmin');
			}elseif(isset($this->session->userdata['flatOwner'])){
				$data['user'] = $this->session->userdata('flatOwner');
			}
			$data['error'] = $this->session->flashdata('error');
			$data['success'] = $this->session->flashdata('success');
			$data['Disabled'] = $this->session->flashdata('Disabled');
			$data['page'] = 'dashboard';
			$data['familyMember'] = $this->Home_model->fetch_details(array('family_mem_id'=>$data['user']['id']),'rs_familymember');
			$data['vehicleDetails'] = $this->Home_model->fetch_details(array('vehicle_mem_id'=>$data['user']['id']),'rs_vehicle');
			$data['memberDetails'] = $this->Home_model->fetch_details(array('member_id'=>$data['user']['id']),'rs_member');
			$data['spouseDetails'] = $this->Home_model->fetch_details(array('family_mem_id'=>$data['user']['id'],'family_mem_relative'=>'Spouse'),'rs_familymember');
			$data['flatDetails'] = $this->Home_model->fetch_details(array('flat_owner_mem_id'=>$data['user']['id']),'rs_flat');
			$data['ownerDetails'] = $this->Home_model->fetch_details(array('owner_mem_id'=>$data['user']['id']),'rs_new_owner_data');
			$this->load->view('Home/header',$data);
			$this->load->view('Home/profile',$data);
		}

		public function update_owner_member()
		{
			$owner_id = $this->input->post('owner_id');
			$owner['owner_name'] = $this->input->post('owner_name');
			$owner['owner_email'] = $this->input->post('owner_email');
			$owner['owner_phone'] = $this->input->post('owner_phone');
			$owner['owner_gender'] = $this->input->post('owner_gender');
			$owner['owner_DOB'] = $this->input->post('owner_DOB');
			$owner['owner_address'] = $this->input->post('owner_address');
			$this->Home_model->update_records(array('id'=>$owner_id),'rs_new_owner_data',$owner);
			$this->session->set_flashdata('active',1);
	        $this->session->set_flashdata('title',"Thank You.");
	        $this->session->set_flashdata('text',"Owner Details updated Successfully."); 
		    $this->session->set_flashdata('type',"success");
		    redirect('profile');
		}

		public function update_flat_details()
		{
			$flat_id = $this->input->post('flat_id');
			$flat['flat_number'] = $this->input->post('flat_number');
			$flat['flat_type'] = $this->input->post('flat_type');
			$flat['flat_area'] = $this->input->post('flat_area');
			$this->Home_model->update_records(array('flat_id'=>$flat_id),'rs_flat',$flat);
			$this->session->set_flashdata('active',1);
	        $this->session->set_flashdata('title',"Thank You.");
	        $this->session->set_flashdata('text',"Flat Details updated Successfully."); 
		    $this->session->set_flashdata('type',"success");
		    redirect('profile');
		}

		public function update_family_member()
		{
			if(isset($this->session->userdata['socAdmin'])){
				$data['user'] = $this->session->userdata('socAdmin');
			}elseif(isset($this->session->userdata['flatOwner'])){
				$data['user'] = $this->session->userdata('flatOwner');
			}
			$family_id = $this->input->post('family_id');			
			$family['family_mem_name'] = $this->input->post('family_mem_name'); 
			$family['family_mem_relative'] = $this->input->post('family_mem_relative'); 
			$family['family_mem_email'] = $this->input->post('family_mem_email'); 
			$family['family_mem_phone'] = $this->input->post('family_mem_phone'); 
			$family['family_mem_occupation'] = $this->input->post('family_mem_occupation'); 
			$family['family_mem_dob'] = $this->input->post('family_mem_dob');
			if($family_id == ''){
				$family['family_mem_id'] = $data['user']['id']; 
				$verify = $this->Home_model->total_records_count(array('family_mem_id'=>$family['family_mem_id'],'family_mem_name'=>''.$family['family_mem_name'].'','family_mem_relative'=>''.$family['family_mem_relative'].''),'rs_familymember');
				if($verify == 0){
					$this->Home_model->insert_records('rs_familymember',$family);
					$this->session->set_flashdata('active',1);
			        $this->session->set_flashdata('title',"Thank You.");
			        $this->session->set_flashdata('text',"Family Member Added Successfully."); 
			        $this->session->set_flashdata('type',"success");
				}else{
					$this->session->set_flashdata('active',1);
			        $this->session->set_flashdata('title',"Thank You.");
			        $this->session->set_flashdata('text',"Family Member already register."); 
			        $this->session->set_flashdata('type',"warning");
				}
			}else{
				$this->Home_model->update_records(array('family_id'=>$family_id),'rs_familymember',$family);
				$this->session->set_flashdata('active',1);
		        $this->session->set_flashdata('title',"Thank You.");
		        $this->session->set_flashdata('text',"Family Member updated Successfully."); 
			    $this->session->set_flashdata('type',"success");
			}  
		    redirect('profile');
		}

		public function update_flat_parking()
		{
			if(isset($this->session->userdata['socAdmin'])){
				$data['user'] = $this->session->userdata('socAdmin');
			}elseif(isset($this->session->userdata['flatOwner'])){
				$data['user'] = $this->session->userdata('flatOwner');
			}
			$vehicle_id = $this->input->post('vehicle_id');
			$par['vehicle_type'] = $this->input->post('vehicle_type');
			$par['vehicle_model'] = $this->input->post('vehicle_model');
			$par['vehicle_no'] = $this->input->post('vehicle_no');
			$par['vehicle_sticker'] = $this->input->post('vehicle_sticker');
			if($vehicle_id == ''){
				$par['vehicle_mem_id'] = $data['user']['id'];
				$verify = $this->Home_model->total_records_count(array('vehicle_mem_id'=>$par['vehicle_mem_id'],'vehicle_model'=>''.$par['vehicle_model'].'','vehicle_no'=>''.$par['vehicle_no'].''),'rs_vehicle');
				if($verify == 0){
					$this->Home_model->insert_records('rs_vehicle',$par);
					$this->session->set_flashdata('active',1);
			        $this->session->set_flashdata('title',"Thank You.");
			        $this->session->set_flashdata('text',"Vehicle Parking Added Successfully."); 
			        $this->session->set_flashdata('type',"success");
				}else{
					$this->session->set_flashdata('active',1);
			        $this->session->set_flashdata('title',"Thank You.");
			        $this->session->set_flashdata('text',"Vehicle already register."); 
			        $this->session->set_flashdata('type',"warning");
				}  
			}else{
				$this->Home_model->update_records(array('vehicle_id'=>$vehicle_id),'rs_vehicle',$par);
				$this->session->set_flashdata('active',1);
		        $this->session->set_flashdata('title',"Thank You.");
		        $this->session->set_flashdata('text',"Flat Parking updated Successfully."); 
			    $this->session->set_flashdata('type',"success");
			}  

		    redirect('profile');
		}

		public function update_member_profile()
		{		
			if(isset($this->session->userdata['socAdmin'])){
				$data['user'] = $this->session->userdata('socAdmin');
			}elseif(isset($this->session->userdata['flatOwner'])){
				$data['user'] = $this->session->userdata('flatOwner');
			}
			$mem['member_name'] = $this->input->post('member_name');
			$mem['member_mobile'] = $this->input->post('member_mobile');
			$mem['member_domain'] = $this->input->post('member_domain');
			$mem['member_occupation'] = $this->input->post('member_occupation');
			$mem['member_gender'] = $this->input->post('member_gender');
			$mem['member_dob'] = $this->input->post('member_dob');
			$mem['member_address'] = $this->input->post('member_address');
			$fam['family_mem_name'] = $this->input->post('family_mem_name');
			$fam['family_mem_email'] = $this->input->post('family_mem_email');
			$fam['family_mem_phone'] = $this->input->post('family_mem_phone');
			$fam['family_mem_gender'] = $this->input->post('family_mem_gender');
			$fam['family_mem_dob'] = $this->input->post('family_mem_dob');
			$fam['family_mem_address'] = $this->input->post('family_mem_address');
			$this->Home_model->update_records(array('member_id'=>$data['user']['id']),'rs_member',$mem);
			$verify_spouse = $this->Home_model->total_records_count(array('family_mem_id'=>$data['user']['id'],'family_mem_relative'=>'Spouse'),'rs_familymember');
			if($verify_spouse != 0){
				$this->Home_model->update_records(array('family_mem_id'=>$data['user']['id'],'family_mem_relative'=>'Spouse'),'rs_familymember',$fam);
			}else{
				$fam['family_mem_relative'] = 'Spouse';
				$fam['family_mem_id'] = $data['user']['id'];
				$this->Home_model->insert_records('rs_familymember',$fam);
				$this->Home_model->update_records(array('family_mem_id'=>$data['user']['id']),'rs_familymember',$mem);
			}
			$spouse_cowner = $this->input->post('spouse_cowner');
			if($spouse_cowner == 'on'){
				$fam['family_mem_co_owner'] = 1;
				$owner['owner_name'] = $this->input->post('family_mem_name');
				$owner['owner_email'] = $this->input->post('family_mem_email');
				$owner['owner_phone'] = $this->input->post('family_mem_phone');
				$owner['owner_gender'] = $this->input->post('family_mem_gender');
				$owner['owner_DOB'] = $this->input->post('family_mem_dob');
				$owner['owner_address'] = $this->input->post('family_mem_address');		
				$owner['owner_mem_id'] = $data['user']['id'];
				$owner['owner_soc_id'] = $data['user']['soc_id'];
				$owner['owner_createdby'] = $data['user']['id'];
				$owner['owner_createdon'] = date('Y-m-d');
				$this->Home_model->insert_records('rs_new_owner_data',$owner);
				$this->Home_model->update_records(array('family_mem_id'=>$data['user']['id'],'family_mem_relative'=>'Spouse'),'rs_familymember',$fam);
			}			
			$this->session->set_flashdata('active',1);
	        $this->session->set_flashdata('title',"Thank You.");
	        $this->session->set_flashdata('text',"Profile Updated Successfully."); 
	        $this->session->set_flashdata('type',"success");
	        redirect('profile');
		}

		public function delete_member_profile()
		{
			$family_id = $this->input->post('family_id');
			$this->Home_model->delete_records(array('family_id'=>$family_id),'rs_familymember');
			$this->session->set_flashdata('active',1);
	        $this->session->set_flashdata('title',"Thank You.");
	        $this->session->set_flashdata('text',"Family Member Deleted."); 
	        $this->session->set_flashdata('type',"success");
	        redirect('profile');
		}

		public function delete_owner_profile()
		{
			$owner_id = $this->input->post('owner_id');
			$owner = $this->Home_model->fetch_details(array('id'=>$owner_id),'rs_new_owner_data');
			if($owner[0]['owner_spouse_id'] == 1){
				// print_r($owner);die();
				$fam['family_mem_co_owner'] = 0;
				$this->Home_model->update_records(array('family_mem_id'=>$owner[0]['owner_mem_id'],'family_mem_relative'=>'Spouse'),'rs_familymember',$fam);
			}
			// die();
			$this->Home_model->delete_records(array('id'=>$owner_id),'rs_new_owner_data');
			$this->session->set_flashdata('active',1);
	        $this->session->set_flashdata('title',"Thank You.");
	        $this->session->set_flashdata('text',"Co Owner Deleted."); 
	        $this->session->set_flashdata('type',"success");
	        redirect('profile');
		}

		public function delete_vehicle_profile()
		{
			$vehicle_id = $this->input->post('vehicle_id');
			$this->Home_model->delete_records(array('vehicle_id'=>$vehicle_id),'rs_vehicle');
			$this->session->set_flashdata('active',1);
	        $this->session->set_flashdata('title',"Thank You.");
	        $this->session->set_flashdata('text',"Vehicle Parking Deleted."); 
	        $this->session->set_flashdata('type',"success");
	        redirect('profile');
		}

		public function fetch_member_records()
		{
			$family_id = $_POST['id'];
			$data = $this->Home_model->fetch_details(array('family_id'=>$family_id),'rs_familymember');
			echo json_encode($data);
		}

		public function fetch_vehicle_records()
		{
			$vehicle_id = $_POST['id'];
			$data = $this->Home_model->fetch_details(array('vehicle_id'=>$vehicle_id),'rs_vehicle');
			echo json_encode($data);
		}

		public function fetch_owner_records()
		{
			$owner_id = $_POST['id'];
			$data = $this->Home_model->fetch_details(array('id'=>$owner_id),'rs_new_owner_data');
			echo json_encode($data);
		}

		public function fetch_flat_records()
		{
			$flat_id = $_POST['id'];
			$data = $this->Home_model->fetch_details(array('flat_id'=>$flat_id),'rs_flat');
			echo json_encode($data);
		}

		public function change_pwd()
		{
			if(isset($this->session->userdata['mainAdmin'])){
				$data['user'] = $this->session->userdata('mainAdmin');
			}elseif(isset($this->session->userdata['socAdmin'])){
				$data['user'] = $this->session->userdata('socAdmin');
			}elseif(isset($this->session->userdata['flatOwner'])){
				$data['user'] = $this->session->userdata('flatOwner');
			}elseif(isset($this->session->userdata['socChairman'])){
				$data['user'] = $this->session->userdata('socChairman');
			}else{
				redirect('/');				
			}
			$data['member'] = $this->Home_model->fetch_details(array('member_id'=>$data['user']['id']),'rs_member');
			$data['page'] = 'dashboard';
			$this->load->view('Home/header',$data);
			$this->load->view('Home/change_pwd',$data);
			$this->load->view('Home/footer',$data);
		}

		public function update_pwd()
		{
			$user['member_email'] = $this->input->post('member_email');
			$password = $this->input->post('member_password');
			$user['member_salt'] = $this->Home_model->salt(32); 
			$user['member_password'] =$this->Home_model->make($password.$user['member_salt']); 
			$this->db->where('member_email',$user['member_email'])->update('rs_member',$user);
			$this->session->set_flashdata('active',1);
	        $this->session->set_flashdata('title',"Thank You.");
	        $this->session->set_flashdata('text',"Member password Updated Successfully."); 
	        $this->session->set_flashdata('type',"success");
	        redirect('Dashboard');
		}

		public function update_personal_info()
		{
			parse_str($_POST["data"], $_POST);
			$member_id = $_POST['member_id'];
			$member['member_name'] = $_POST['member_name'];
			// $member['member_email'] = $_POST['member_email'];
			$member['member_mobile'] = $_POST['member_mobile'];
			$member['member_domain'] = $_POST['member_domain'];
			$member['member_occupation'] = $_POST['member_occupation'];
			$member['member_gender'] = $_POST['member_gender'];
			$member['member_dob'] = $_POST['member_dob'];
			$member['member_address'] = $_POST['member_address'];
			$this->Home_model->update_records('member_id='.$member_id.'','rs_member',$member);
			echo json_encode("Successfully updated information");
		}

		public function	update_spouse_info()
		{
			parse_str($_POST["data"], $_POST);
			$member_id = $_POST['member_id'];
			$fam['family_mem_name'] = $_POST['family_mem_name'];
			$fam['family_mem_email'] = $_POST['family_mem_email'];
			$fam['family_mem_phone'] = $_POST['family_mem_phone'];
			$fam['family_mem_gender'] = $_POST['family_mem_gender'];
			$fam['family_mem_dob'] = $_POST['family_mem_dob'];
			$fam['family_mem_address'] = $_POST['family_mem_address'];
			$verify_spouse = $this->Home_model->total_records_count(array('family_mem_id'=>$member_id,'family_mem_relative'=>'Spouse'),'rs_familymember');
			if($verify_spouse != 0){
				$this->Home_model->update_records(array('family_mem_id'=>$member_id,'family_mem_relative'=>'Spouse'),'rs_familymember',$fam);
			}else{
				$fam['family_mem_relative'] = 'Spouse';
				$fam['family_mem_id'] = $member_id;
				$this->Home_model->insert_records('rs_familymember',$fam);
				$this->Home_model->update_records(array('family_mem_id'=>$member_id),'rs_familymember',$mem);
			}
			echo json_encode("Successfully updated spouse information");
		}

		public function	update_joint_owner_info()
		{

			if(isset($this->session->userdata['socAdmin'])){
				$data['user'] = $this->session->userdata('socAdmin');
			}elseif(isset($this->session->userdata['flatOwner'])){
				$data['user'] = $this->session->userdata('flatOwner');
			}
			parse_str($_POST["data"], $_POST);
			$member_id = $_POST['member_id'];
			$spouse_cowner = $_POST['spouse_cowner'];
			if($spouse_cowner == 'on'){
				$fam['family_mem_co_owner'] = 1;
				$owner['owner_name'] = $_POST['family_mem_name'];
				$owner['owner_email'] = $_POST['family_mem_email'];
				$owner['owner_phone'] = $_POST['family_mem_phone'];
				$owner['owner_gender'] = $_POST['family_mem_gender'];
				$owner['owner_DOB'] = $_POST['family_mem_dob'];
				$owner['owner_address'] = $_POST['family_mem_address'];	
				$owner['owner_mem_id'] = $member_id;
				$owner['owner_spouse_id'] = 1;
				$owner['owner_soc_id'] = $data['user']['soc_id'];
				$owner['owner_createdby'] = $member_id;
				$owner['owner_createdon'] = date('Y-m-d');
				$this->Home_model->insert_records('rs_new_owner_data',$owner);
				$this->Home_model->update_records(array('family_mem_id'=>$member_id,'family_mem_relative'=>'Spouse'),'rs_familymember',$fam);
			}			
			
			echo json_encode("Successfully updated spouse as joint owner information");
		}

		public function upload_summ_image()
		{
			$return_value = '';
			if ($_FILES['image_file']['name']) {
				if (!$_FILES['image_file']['error']) {
					$name = md5(rand(100, 200));
					$ext = explode('.', $_FILES['image_file']['name']);
					$filename = $name . '.' . $ext[1];
					$destination = base_url('assets/images/'). $filename.'';
					$location = $_FILES['image_file']['tmp_name'];
					move_uploaded_file($_FILES['image_file']['tmp_name'], $destination);
					echo ''.base_url().'assets/images/' . $filename.'';
				}else{
					$return_value = '../assets/images/: '.$_FILES['image_file']['error'];
				}
			}
			// echo json_encode($destination);
		}

		public function ajax_upload()
		{
			if(isset($this->session->userdata['socAdmin'])){
				$data['user'] = $this->session->userdata('socAdmin');
			}elseif(isset($this->session->userdata['flatOwner'])){
				$data['user'] = $this->session->userdata('flatOwner');
			}
			if($_FILES["file"]["name"]){
				$test =explode(".", $_FILES['file']['name']);
				$extension = end($test);
				$name =$data['user']['id'] . '.' . $extension;
				$location = $_SERVER['DOCUMENT_ROOT'] .'/Colonia/assets/images/'.$name;
				move_uploaded_file($_FILES['file']['tmp_name'], $location);
				$this->Home_model->update_records('member_id='.$data['user']['id'].'','rs_member',array('member_photo_link'=>''.base_url().'/assets/images/'.$name.''));
				echo '<img src="'.base_url().'/assets/images/'.$name.'" class="image-responsive" style="width: 12%;border-radius: 63%;border: 1px solid black;"/>';
			}
		}
	}
?>